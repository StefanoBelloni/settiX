Emacs demo setup for C/C++ describe here: http://tuhdo.github.io/c-ide.html
